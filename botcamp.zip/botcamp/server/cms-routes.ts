import { Router } from "express";
import { db } from "./db";
import { 
  sitePages, 
  siteContentBlocks,
  insertSitePageSchema,
  insertSiteContentBlockSchema
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { requireAdmin, logAudit } from "./rbac";

const router = Router();

// ========================
// SITE PAGES (ADMIN & OWNER)
// ========================

// Get all pages
router.get("/pages", async (req, res) => {
  try {
    const { includeInactive = "false" } = req.query;

    let query = db.select().from(sitePages).orderBy(sitePages.createdAt);

    if (includeInactive !== "true") {
      query = query.where(eq(sitePages.isActive, true)) as any;
    }

    const pages = await query;

    res.json(pages);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get page by slug (public route)
router.get("/pages/slug/:slug", async (req, res) => {
  try {
    const { slug } = req.params;

    const page = await db.query.sitePages.findFirst({
      where: eq(sitePages.slug, slug),
    });

    if (!page) {
      return res.status(404).json({ message: "Página não encontrada" });
    }

    if (!page.isActive) {
      return res.status(404).json({ message: "Página não disponível" });
    }

    // Get content blocks for this page
    const blocks = await db
      .select()
      .from(siteContentBlocks)
      .where(eq(siteContentBlocks.pageId, page.id))
      .orderBy(siteContentBlocks.order);

    res.json({ page, blocks });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get page by ID
router.get("/pages/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const page = await db.query.sitePages.findFirst({
      where: eq(sitePages.id, id),
    });

    if (!page) {
      return res.status(404).json({ message: "Página não encontrada" });
    }

    // Get content blocks for this page
    const blocks = await db
      .select()
      .from(siteContentBlocks)
      .where(eq(siteContentBlocks.pageId, id))
      .orderBy(siteContentBlocks.order);

    res.json({ page, blocks });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Create new page (ADMIN & OWNER only)
router.post("/pages", requireAdmin, async (req, res) => {
  try {
    const pageData = insertSitePageSchema.parse(req.body);

    const [newPage] = await db
      .insert(sitePages)
      .values({
        ...pageData,
        lastEditedBy: req.user!.id,
      })
      .returning();

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "create_page",
      entityType: "site_page",
      entityId: newPage.id,
      newValue: newPage,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(201).json(newPage);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Update page (ADMIN & OWNER only)
router.put("/pages/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const existingPage = await db.query.sitePages.findFirst({
      where: eq(sitePages.id, id),
    });

    if (!existingPage) {
      return res.status(404).json({ message: "Página não encontrada" });
    }

    const pageData = insertSitePageSchema.partial().parse(req.body);

    const [updatedPage] = await db
      .update(sitePages)
      .set({
        ...pageData,
        lastEditedBy: req.user!.id,
        updatedAt: new Date(),
      })
      .where(eq(sitePages.id, id))
      .returning();

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "update_page",
      entityType: "site_page",
      entityId: id,
      oldValue: existingPage,
      newValue: updatedPage,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(updatedPage);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Delete page (ADMIN & OWNER only)
router.delete("/pages/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const existingPage = await db.query.sitePages.findFirst({
      where: eq(sitePages.id, id),
    });

    if (!existingPage) {
      return res.status(404).json({ message: "Página não encontrada" });
    }

    await db.delete(sitePages).where(eq(sitePages.id, id));

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      action: "delete_page",
      entityType: "site_page",
      entityId: id,
      oldValue: existingPage,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Página deletada com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ========================
// CONTENT BLOCKS (ADMIN & OWNER)
// ========================

// Get blocks for a page
router.get("/pages/:pageId/blocks", async (req, res) => {
  try {
    const { pageId } = req.params;

    const blocks = await db
      .select()
      .from(siteContentBlocks)
      .where(eq(siteContentBlocks.pageId, pageId))
      .orderBy(siteContentBlocks.order);

    res.json(blocks);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Create content block (ADMIN & OWNER only)
router.post("/pages/:pageId/blocks", requireAdmin, async (req, res) => {
  try {
    const { pageId } = req.params;

    // Verify page exists
    const page = await db.query.sitePages.findFirst({
      where: eq(sitePages.id, pageId),
    });

    if (!page) {
      return res.status(404).json({ message: "Página não encontrada" });
    }

    const blockData = insertSiteContentBlockSchema.parse({
      ...req.body,
      pageId,
    });

    const [newBlock] = await db
      .insert(siteContentBlocks)
      .values(blockData)
      .returning();

    res.status(201).json(newBlock);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Update content block (ADMIN & OWNER only)
router.put("/blocks/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const existingBlock = await db.query.siteContentBlocks.findFirst({
      where: eq(siteContentBlocks.id, id),
    });

    if (!existingBlock) {
      return res.status(404).json({ message: "Bloco não encontrado" });
    }

    const blockData = insertSiteContentBlockSchema.partial().parse(req.body);

    const [updatedBlock] = await db
      .update(siteContentBlocks)
      .set({
        ...blockData,
        updatedAt: new Date(),
      })
      .where(eq(siteContentBlocks.id, id))
      .returning();

    res.json(updatedBlock);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

// Delete content block (ADMIN & OWNER only)
router.delete("/blocks/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const existingBlock = await db.query.siteContentBlocks.findFirst({
      where: eq(siteContentBlocks.id, id),
    });

    if (!existingBlock) {
      return res.status(404).json({ message: "Bloco não encontrado" });
    }

    await db.delete(siteContentBlocks).where(eq(siteContentBlocks.id, id));

    res.json({ message: "Bloco deletado com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Reorder blocks (ADMIN & OWNER only)
router.post("/pages/:pageId/blocks/reorder", requireAdmin, async (req, res) => {
  try {
    const { pageId } = req.params;
    const { blocks } = req.body; // Array of { id, order }

    if (!Array.isArray(blocks)) {
      return res.status(400).json({ message: "Blocks deve ser um array" });
    }

    // Update all blocks in a transaction
    for (const block of blocks) {
      await db
        .update(siteContentBlocks)
        .set({ order: block.order })
        .where(eq(siteContentBlocks.id, block.id));
    }

    res.json({ message: "Blocos reordenados com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
