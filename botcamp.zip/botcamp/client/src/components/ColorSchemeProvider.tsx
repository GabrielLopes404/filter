import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

interface UserPreferences {
  colorScheme: string;
}

export default function ColorSchemeProvider({ children }: { children: React.ReactNode }) {
  const [colorScheme, setColorScheme] = useState("purple");

  const { data: userPreferences } = useQuery<UserPreferences>({
    queryKey: ["/api/user/preferences"],
    queryFn: async () => {
      const res = await fetch("/api/user/preferences", { credentials: "include" });
      if (!res.ok) {
        if (res.status === 401) {
          return { colorScheme: "purple" };
        }
        throw new Error("Failed to fetch preferences");
      }
      return res.json();
    },
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (userPreferences?.colorScheme) {
      setColorScheme(userPreferences.colorScheme);
    }
  }, [userPreferences]);

  useEffect(() => {
    const colorMap: Record<string, string> = {
      purple: '270 91% 65%',
      blue: '217 91% 60%',
      green: '142 76% 36%',
      orange: '25 95% 53%',
      pink: '330 81% 60%',
    };
    
    const hslColor = colorMap[colorScheme] || colorMap.purple;
    document.documentElement.style.setProperty('--primary', hslColor);
  }, [colorScheme]);

  return <>{children}</>;
}
